export class StringCalculator {
    add(numbers: string): number {
      if (!numbers) return 0;
  
      let delimiter = /,|\n/;
  
      if (numbers.startsWith('//')) {
        const delimiterEnd = numbers.indexOf('\n');
        let delimiters = numbers.substring(2, delimiterEnd);
  
        if (delimiters.startsWith('[') && delimiters.endsWith(']')) {
          delimiters = delimiters.slice(1, -1);
          const delimiterArray = delimiters.split('][').map(d => d.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'));
          delimiter = new RegExp(delimiterArray.join('|'));
        } else {
          delimiter = new RegExp(delimiters.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'));
        }
  
        numbers = numbers.substring(delimiterEnd + 1);
      }
  
      const numberArray = numbers.split(delimiter).map(num => parseInt(num, 10));
      const negatives = numberArray.filter(num => num < 0);
  
      if (negatives.length > 0) {
        throw new Error(`negative numbers not allowed: ${negatives.join(', ')}`);
      }
  
      return numberArray.reduce((sum, num) => sum + num, 0);
    }
  }
  