### Running Projects and Installing npm Packages (npm i )

#### Running a Project

1. **Navigate to Project Directory:**
   Open your command line interface (CLI) and navigate to the directory where your Node.js project is located.

   ```bash
   cd /path/to/your/project(npm test)
